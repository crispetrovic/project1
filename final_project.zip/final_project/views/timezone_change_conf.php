<!DOCTYPE html>
<title> Timezone Changed! </title>
<?php
    // Notify user of successful password change
    print("Your timezone has been changed.");
?>