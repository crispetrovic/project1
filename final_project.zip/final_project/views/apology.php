<h1>Whoops!</h1>
<p><?= htmlspecialchars($message) ?></p>

<div>
   <a href="javascript:history.go(-1)"><strong> Go back. </strong></a>
</div>