<!DOCTYPE html>
<title> Password Changed! </title>
<?php
    // Notify user of successful password change
    print("Your password has been successfully changed.");
?>