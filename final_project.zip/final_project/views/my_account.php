<!DOCTYPE html>
<title> My Account </title>
<body>
    
    <h3> My Account </h3>
    
    <br>
    <p>
        Need to change your password? 
        <a href="password.php">Click here.</a></li>
    </p>
    <br> 
    <br>
    <p>   
        Deactivate your account. | *This cannot be undone.<br>
        
            <form name="report" action="my_account_options.php" method=post>  
            <button type="submit"  class="btn btn-default">Deactivate</button>
            </form>
            
    </p>
    
</body>
