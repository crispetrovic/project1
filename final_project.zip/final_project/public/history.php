<!DOCTYPE html>
<title> History </title>

<?php

    // call configuration
    require("../includes/config.php");  
    
    
    // create array into which all history info will be stored
    $table = CS50::query("SELECT * FROM history WHERE user_id = ?", $_SESSION["id"]);
    
    // render history form
    render("history_request.php", ["title" => "My Feelings", "table" => $table]);
    
   
?>


